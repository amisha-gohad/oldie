struct record

{

    char timee[6];

    char namee[30];

    char placee[25];

    char durationn[10];

    char notee[500];

} ;
