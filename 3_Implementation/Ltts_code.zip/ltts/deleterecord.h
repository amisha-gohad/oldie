#ifndef Func7
#define Func7
#include <stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>

// declares a function
void deleterecord();
#endif