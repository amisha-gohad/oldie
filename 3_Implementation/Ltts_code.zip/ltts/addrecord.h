#ifndef Func1
#define Func1
#include <stdio.h>
#include<stdlib.h>

#include<conio.h>

#include<string.h>

// declares a function
void addrecord();
#endif