#ifndef Func2
#define Func2
#include <stdio.h>
#include<stdlib.h>

#include<conio.h>
#include<string.h>
// declares a function
void viewrecord();
#endif